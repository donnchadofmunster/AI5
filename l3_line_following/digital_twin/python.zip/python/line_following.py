#-----------------------------------------------------------------------------#
#------------------Skills Progression 1 - Task Automation---------------------#
#-----------------------------------------------------------------------------#
#----------------------------Lab 3 - Line Following---------------------------#
#-----------------------------------------------------------------------------#

# Imports
from pal.products.qbot_platform import QBotPlatformDriver, Keyboard, \
    QBotPlatformCSICamera, QBotPlatformRealSense, QBotPlatformLidar
from hal.content.qbot_platform_functions import QBPVision
from quanser.hardware import HILError
from pal.utilities.probe import Probe
import time
import numpy as np
import cv2
from qlabs_setup import setup

# Section A - Setup

setup(locationQBotP=[-1.35, 0.3, 0.05], rotationQBotP=[0, 0, 0], verbose=True)
time.sleep(2)
ipHost, ipDriver = 'localhost', 'localhost'
commands, arm, noKill = np.zeros((2), dtype=np.float64), 0, True
frameRate, sampleRate = 60.0, 1/60.0
counter, counterDown = 0, 0
endFlag, offset, forSpd, turnSpd = False, 0, 0, 0
startTime = time.time()

def elapsed_time():
    return time.time() - startTime

timeHIL, prevTimeHIL = elapsed_time(), elapsed_time() - 0.017

try:
    # Section B - Initialization
    myQBot = QBotPlatformDriver(mode=1, ip=ipDriver)
    downCam = QBotPlatformCSICamera(frameRate=60.0, exposure=39.0, gain=17.0)
    lidar = QBotPlatformLidar()  # Added Lidar initialization
    keyboard = Keyboard()
    vision = QBPVision()
    probe = Probe(ip=ipHost)
    probe.add_display(imageSize=[200, 320, 1], scaling=True, scalingFactor=2, name='Raw Image')
    probe.add_display(imageSize=[50, 320, 1], scaling=False, scalingFactor=2, name='Binary Image')
    line2SpdMap = vision.line_to_speed_map(sampleRate, 75)
    next(line2SpdMap)
    startTime = time.time()
    time.sleep(0.5)

    # Main loop
    while noKill and not endFlag:
        t = elapsed_time()

        if not probe.connected:
            probe.check_connection()

        if probe.connected:
            # Keyboard Driver
            newkeyboard = keyboard.read()
            if newkeyboard:
                arm = keyboard.k_space
                lineFollow = keyboard.k_7
                keyboardCommand = keyboard.bodyCmd
                if keyboard.k_u:
                    noKill = False

        # Section C - toggle line following
        if not lineFollow:
            print("🕹️ Manual Mode: Controlling Robot via Keyboard")
            commands[:] = [keyboardCommand[0], keyboardCommand[1]]
        else:
            print("🤖 Line-Following Mode: Autonomous Movement")
            commands[:] = [forSpd, turnSpd]

            print(f"✅ Movement Command Sent → Forward Speed: {commands[0]}, Turn Speed: {commands[1]}")

            # QBot Hardware
            newHIL = myQBot.read_write_std(timestamp=time.time() - startTime,
                                           arm=arm,
                                           commands=commands)
            if newHIL:
                timeHIL = time.time()
                newDownCam = downCam.read()
                if newDownCam:
                    counterDown += 1

                    # Section D - Image processing

                    # Section D.1 - Undistort and resize the image
                    undistorted = vision.df_camera_undistort(downCam.imageData)
                    gray_sm = cv2.resize(undistorted, (640, 400))  # Keep original size

                    newDownCam = downCam.read()
                    input_image = downCam.imageData  # Get downward-facing camera image

                    if newDownCam:
                        if input_image is not None and input_image.size > 0:
                            print(f"✅ Captured Input Image Shape: {input_image.shape}")
                            cv2.imwrite("debug_input_image.jpg", input_image)  # Save the raw image
                        else:
                            print("❌ Error: `input_image` is empty or not captured correctly!")

                        save_path = "C:/Users/abdal/Documents/Quanser/debug_input_image.jpg"
                        cv2.imwrite(save_path, input_image)
                        print(f"✅ Image saved at: {save_path}")


                    # # Read depth image from the RealSense camera
                    # depth_image = depthCam.read()

                    # if depth_image is not None and depth_image.size > 0:
                    #     print(f"✅ Captured Depth Image Shape: {depth_image.shape}")

                    #     # Normalize Depth Data (Rescale to 0-255)
                    #     depth_gray = cv2.normalize(depth_image, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)

                    #     # Apply Adaptive Thresholding to Extract the Line
                    #     _, binary = cv2.threshold(depth_gray, 80, 255, cv2.THRESH_BINARY_INV)

                    #     cv2.imwrite("debug_depth_binary.jpg", binary)  # Debugging output
                    #     print("✅ Depth Binary Image Saved for Debugging.")

                    # else:
                    #     print("❌ Depth image not captured correctly!")


                    #------- Image Processing Update --------#
                    print(f"✅ Original Image Shape: {input_image.shape}")

                    binary = vision.subselect_and_threshold(input_image, rowStart=120, rowEnd=250, minThreshold=30, maxThreshold=220)

                    if binary is None or binary.size == 0:
                        print("❌ ERROR: Binary image is empty. No valid thresholding applied!")
                    else:
                        print(f"✅ Extracted Binary Image Shape: {binary.shape}")

                    # Morphological Operations for Noise Reduction
                    kernel = np.ones((7, 7), np.uint8)  # Larger kernel for better filtering
                    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)  # Fill small gaps
                    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)  # Remove noise


                    cv2.imwrite("debug_binary2.jpg", binary)  # Save binary image for debugging
                    print("✅ Binary Image Saved for Debugging")

                    # Read Lidar Data
                    lidar_data = lidar.read()
                    if lidar_data is not None:
                        print(f"✅ Lidar Data Captured → Min Distance: {np.min(lidar_data)} meters")
                        if np.min(lidar_data) < 0.3:
                            print("🚨 Obstacle Detected! Stopping the robot.")
                            forSpd, turnSpd = 0, 0  # Stop the robot if an obstacle is too close

                    # Blob Detection via Connected Component Labeling
                    col, row, area = vision.image_find_objects(binary, 8, 1500, 25000)

                    # Section D.2 - Speed command from blob information
                    if col is None:  # No valid object detected
                        print("❌ No line detected! Trying to recover...")
                        forSpd, turnSpd = 0.05, 0.3  # Slow forward motion + slight turn to search
                    else:
                        print(f"✅ Line Detected → Column: {col:.2f}, Row: {row:.2f}, Area: {area}")
                        forSpd, turnSpd = line2SpdMap.send((col, 0, 0))  # Send blob information to speed map

                if counterDown % 4 == 0:
                    try:
                        if binary is not None and binary.size > 0:
                            resized_binary = cv2.resize(binary, (640, 200))  # Adjusted for visibility
                        else:
                            print("❌ Error: `binary` is empty, skipping probe update.")

                    except Exception as e:
                        print(f"❌ Exception occurred while sending images to probe: {e}")

                prevTimeHIL = timeHIL  # Update time for HIL loop

        # Keyboard Handling
        newkeyboard = keyboard.read()
        if newkeyboard:
            print(f"✅ Keyboard Read Successfully: {newkeyboard}")

            if keyboard.k_space:
                print("✅ Space Bar Pressed: Robot is Armed")
                arm = 1  
            else:
                print("❌ Space Bar Not Pressed")

            if keyboard.k_7:
                print("✅ Line-Following Mode Activated")
                lineFollow = 1
            else:
                print("❌ 7 Key Not Pressed")

            if keyboard.k_u:
                print("🛑 U Key Pressed: Stopping Robot")
                noKill = False

except KeyboardInterrupt:
    print('User interrupted.')
except HILError as h:
    print(h.get_error_message())
finally:
    downCam.terminate()
    lidar.terminate()
    myQBot.terminate()
    probe.terminate()
    keyboard.terminate()
